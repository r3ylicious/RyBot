# RY Discord Bot

Upload `package.json`, `src/index.js`, `.gitignore`, `README.md`, and optional `welcome.mp3` ke GitHub. Jangan upload token, `.env`, atau `config.json`.

## Render
Buat **Background Worker**, sambungkan repository.
Build Command: `npm install`
Start Command: `npm start`
Render > Environment: `DISCORD_TOKEN` = token bot, `PREFIX` = `ry!` (opsional). Jangan taruh token di kode atau GitHub.

Discord Developer Portal > Bot: aktifkan Server Members Intent dan Message Content Intent. Berikan bot permission Manage Channels, Manage Roles, View Channels, Send Messages, Read Message History, Connect, Speak, Attach Files. Role bot harus berada di atas Verified dan Staff.

Jalankan `ry!setup all` sebagai Administrator. Member join voice `welcome` untuk audio dan role Verified. Perintah: `ry!setup welcome`, `ry!setup ticket`, `ry!setup vouches`, `ry!welcome test`, `ry!vouches @member pesan`, `ry!ticket close`, `ry!help`.

Simpan audio dengan nama `welcome.mp3` di root repository (sejajar package.json). Bila file audio tidak ada atau gagal, bot tetap mencoba memberi role. `config.json` menyimpan ID role/channel. Render filesystem biasa bisa hilang saat redeploy; bila ID config hilang, jalankan `ry!setup all` lagi. Setup all dapat mengirim ulang panel ticket/pesan.
